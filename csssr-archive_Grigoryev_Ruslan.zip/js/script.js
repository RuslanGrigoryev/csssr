$(function() {
  $( "#slider" ).slider({
    value:400,
    min: 0,
    max: 800,
    step: 5
  });
});
